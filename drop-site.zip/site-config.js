/**
 * Use YOUR hosted pages only — do not link to s3.amazonaws.com/idecompiler/open
 * (that copy generates random addresses on Copy Address).
 *
 * After upload, set these to your bucket URLs, or leave IDE unset to use ide.html on the same host.
 */
window.SITE_PUBLIC_URL = "https://s3.amazonaws.com/idecompiler/index.html";

/** Compiler page on YOUR bucket — upload open.html as S3 key "open" OR use ide.html */
window.IDE_PAGE_URL = "https://s3.amazonaws.com/idecompiler/open";

// Safer default when config is loaded on your own host: same-origin compiler
if (typeof window !== "undefined" && window.location && window.location.hostname) {
  const host = window.location.hostname;
  if (host && !host.includes("danielcrypto-web3")) {
    try {
      const sameOriginOpen = new URL("open", window.location.href).href;
      const sameOriginIde = new URL("ide.html", window.location.href).href;
      window.IDE_PAGE_URL = sameOriginOpen;
      window.SITE_PUBLIC_URL = window.location.href.split("#")[0];
    } catch {
      window.IDE_PAGE_URL = "ide.html";
    }
  }
}
